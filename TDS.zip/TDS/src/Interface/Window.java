package Interface;

public class Window {
    int x,y;
    int sizeX,sizeY;

}
