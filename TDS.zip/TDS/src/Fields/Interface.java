package Fields;

import Landscape.Map1;
import Objects.Buildings.Base;
import Objects.Unit;
import Players.Player;
import Resources.ResLoader;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;

import java.util.ArrayList;

public class Interface {
    Graphics graphics;
    float step = GameField.step;
    ArrayList<Base> bases = GameField.bases;
    float cameraX = GameField.cameraX;
    float height = GameField.height;
    private int countButtons;
    private GameField gf;

    public Interface(Graphics graphics, GameField gameField) {
        this.graphics = graphics;
        gf = gameField;
    }

    private void menLine(Image img, String menLine) {
        graphics.setColor(Color.black);
        graphics.drawString(menLine, -cameraX + step / 3, height - img.getHeight() + step / 4);
        graphics.setColor(Color.white);
    }

    void setValues(float cameraX, ArrayList<Base> bases, String typeMen, int countButtons) {
        this.cameraX = cameraX;
        this.bases = bases;
        this.countButtons = countButtons;
    }

    boolean touchedInterface(float xMouse, float yMouse) {
        boolean result = false;
        float size = ResLoader.getBuild1().getWidth();
        if (xMouse + cameraX < size * countButtons && yMouse > height - size * 2)
            result = true;
        return result;
    }

    private void selectIdlers() {
        ArrayList<Unit> units = gf.units;
        for (Unit unit : units) {
            unit.chosen = false;
            if (unit.getCondition().equals("Moving") && unit.getType().equals("Worker")) {
                gf.setUnitChosen(unit);
            }
        }
    }

    public void updateMen(String type, Input in, int thisFlag, float xMouse, float yMouse) {
        ArrayList<Player> players = GameField.players;
        switch (type) {
            default:
                gf.countButtons = 2;
                break;
            case "Barracks":
                if (!in.isMousePressed(Input.MOUSE_LEFT_BUTTON))
                    break;
                gf.countButtons = 4;
                switch (numButton(xMouse, yMouse)) {
                    default:
                        for (Base base : bases) {
                            if (base.isCurrent && base.getType().equals("Barracks")
                                    && players.get(0).money >= Base.getPrice("Tank" + numButton(xMouse, yMouse))) {
                                base.addToQueue("Tank" + numButton(xMouse, yMouse));
                                players.get(0).money -= Base.getPrice("Tank" + numButton(xMouse, yMouse));
                            }
                        }
                }
                break;
            case "Centre":
                if (!in.isMousePressed(Input.MOUSE_LEFT_BUTTON))
                    break;
                gf.countButtons = 2;
                switch (numButton(xMouse, yMouse)) {
                    case 1:
                        for (Base base : bases) {
                            if (base.isCurrent && base.getType().equals("Centre")
                                    && players.get(0).money >= Base.getPrice("Worker")) {
                                base.addToQueue("Worker");
                                players.get(0).money -= Base.getPrice("Worker");
                            }
                        }
                        return;
                    case 2:
                        selectIdlers();
                        return;
                }
                break;
            case "Build":
                if (!in.isMousePressed(Input.MOUSE_LEFT_BUTTON))
                    break;
                gf.countButtons = 4;
                switch (numButton(xMouse, yMouse)) {
                    case 1:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Barracks");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 2:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Energy");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 3:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Centre");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 4:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Storage");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 5:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Battery");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 6:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Academy");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 7:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "Turret");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                    case 8:
                        gf.building = new Base(xMouse, Map1.getLevel(), thisFlag, "ResourceS");
                        gf.building.setHp(gf.building.getMaxHp());
                        gf.typeMen = "Placement";
                        return;
                }
                break;
        }
        return;
    }

    int numButton(float xMouse, float yMouse) {
        int size = ResLoader.getBuild1().getWidth();
        if (xMouse + cameraX < size && yMouse > height - size)
            return 1;
        if (xMouse + cameraX < size * 2 && yMouse > height - size &&
                xMouse + cameraX > size)
            return 2;
        if (xMouse + cameraX < size * 3 && yMouse > height - size &&
                xMouse + cameraX > size * 2)
            return 3;
        if (xMouse + cameraX < size * 4 && yMouse > height - size &&
                xMouse + cameraX > size * 3)
            return 4;
        if (xMouse + cameraX < size && yMouse > height - size * 2 && yMouse < height - size)
            return 5;
        if (xMouse + cameraX > size && xMouse + cameraX < size * 2
                && yMouse > height - size * 2 && yMouse < height - size)
            return 6;
        if (xMouse + cameraX > size * 2 && xMouse + cameraX < size * 3
                && yMouse > height - size * 2 && yMouse < height - size)
            return 7;
        if (xMouse + cameraX > size * 3 && xMouse + cameraX < size * 4
                && yMouse > height - size * 2 && yMouse < height - size)
            return 8;
        return 0;
    }

    void drawMen(String type, String menLine) {
        Image img;
        int count1 = 0, count2 = 0, count3 = 0;
        float per1 = 0, per2 = 0, per3 = 0;
        switch (type) {
            case "Build":
                img = ResLoader.getImage("Panel");
                img.draw(-cameraX, height - img.getHeight());
                menLine(img, menLine);
                img = ResLoader.getBuild1();
                img.draw(-cameraX, height - img.getHeight());
                img = ResLoader.getBuild2();
                img.draw(-cameraX + img.getWidth(), height - img.getHeight());
                img = ResLoader.getBuild3();
                img.draw(-cameraX + img.getWidth() * 2, height - img.getHeight());
                img = ResLoader.getImage("Build4");
                img.draw(-cameraX + img.getWidth() * 3, height - img.getHeight());
                img = ResLoader.getImage("Build5");
                img.draw(-cameraX, height - img.getHeight() * 2);
                img = ResLoader.getImage("Build6");
                img.draw(-cameraX + img.getWidth(), height - img.getHeight() * 2);
                img = ResLoader.getImage("Build7");
                img.draw(-cameraX + img.getWidth() * 2, height - img.getHeight() * 2);
                break;
            case "Centre":
                img = ResLoader.getImage("PanelSmall");
                img.draw(-cameraX, height - img.getHeight());
                menLine(img, menLine);
                img = ResLoader.getImage("DroneI");
                img.draw(-cameraX, height - img.getHeight());
                img = ResLoader.getImage("ChooseIdle");
                img.draw(-cameraX + img.getWidth(), height - img.getHeight());
                float timer = 0, spawnTime = 0;
                int count = 0;
                for (Base base : bases) {
                    if (base.isCurrent && base.getType().equals("Centre")) {
                        count += base.units.size();
                        if (base.timer > timer)
                            timer = base.timer;
                        if (base.units.size() > 0)
                            spawnTime = base.units.get(0).spawnTime;
                    }
                }
                graphics.drawString(count + "", -cameraX, height - img.getHeight());
                if (spawnTime != 0)
                    graphics.drawString(Math.round(timer * 100 / spawnTime) + "%",
                            -cameraX + step, height - img.getHeight());
                break;
            case "Barracks":
                img = ResLoader.getImage("Panel");
                img.draw(-cameraX, height - img.getHeight());
                menLine(img, menLine);
                img = ResLoader.getImage("Tank1I");
                img.draw(-cameraX, height - img.getHeight());
                img = ResLoader.getImage("Tank2I");
                img.draw(-cameraX + img.getWidth(), height - img.getHeight());
                img = ResLoader.getImage("Tank3I");
                img.draw(-cameraX + img.getWidth() * 2, height - img.getHeight());
                for (Base base : bases) {
                    if (base.isCurrent && base.getType().equals("Barracks")) {
                        count1 += base.countQueue("Tank1");
                        count2 += base.countQueue("Tank2");
                        count3 += base.countQueue("Tank3");
                        if (base.percentages[0] > per1)
                            per1 = base.percentages[0];
                        if (base.percentages[1] > per2)
                            per2 = base.percentages[1];
                        if (base.percentages[2] > per3)
                            per3 = base.percentages[2];
                    }
                }
                if (count1 != 0) {
                    graphics.drawString(count1 + "", -cameraX, height - img.getHeight());
                    if (per1 != 0)
                        graphics.drawString(Math.round(per1 * 100) + "%",
                                -cameraX + step, height - img.getHeight());
                }
                if (count2 != 0) {
                    graphics.drawString(count2 + "", -cameraX + img.getWidth(), height - img.getHeight());
                    if (per2 != 0)
                        graphics.drawString(Math.round(per2 * 100) + "%",
                                -cameraX + img.getWidth() + step, height - img.getHeight());
                }
                if (count3 != 0) {
                    graphics.drawString(count3 + "", -cameraX + img.getWidth() * 2, height - img.getHeight());
                    if (per3 != 0)
                        graphics.drawString(Math.round(per3 * 100) + "%",
                                -cameraX + img.getWidth() * 2 + step, height - img.getHeight());
                }
                break;
        }
    }
}
