package Fields;

import Interface.Button;
import Landscape.Map1;
import Objects.Bubble;
import Objects.Buildings.Base;
import Objects.Fish;
import Objects.Hero;
import Objects.Unit;
import Objects.Units.Rocket;
import Objects.Units.Worker1;
import Players.Player;
import Resources.Iron;
import Resources.ResLoader;
import Resources.Resource;
import Resources.Stone;
import org.newdawn.slick.*;

import java.util.ArrayList;

public class GameField {
    private Hero hero;
    public Base building;
    private GameContainer gmc;
    private static ArrayList<Bubble> bubbles;
    public ArrayList<Unit> units;
    public static ArrayList<Rocket> rockets;
    public static ArrayList<Base> bases;
    private static ArrayList<Resource> resources;
    public static float cameraX, cameraY, step, width, height;
    private float xMouse, yMouse;
    private static int sizeX;
    private String regime = "Survival", menLine = "";
    public String typeMen = "";
    private static ArrayList<Button> buttons;
    private float chX, chY, chX1, chY1;
    private static ArrayList<Fish> fish;
    public static ArrayList<Player> players;
    private Interface inter;
    int countButtons;
    private int thisFlag;

    private enum Touch {
        Click, Choose;
    }

    private void createPlayers(int regime) {
        switch (regime) {
            case 1:
                players.add(new Player(-1, this));
                for (int i = 0; i < 4; i++) {
                    units.add(new Worker1(100 + i * 10, Map1.getLevel(), -1));
                }
                players.get(1).money = 1050;
                players.get(1).stone = 50;
                players.get(1).iron = 50;
                resources.add(new Stone(300,
                        Map1.getLevel() - ResLoader.getImage("Stone").getHeight()));
                resources.add(new Stone(sizeX / 2 - 300,
                        Map1.getLevel() - ResLoader.getImage("Stone").getHeight()));
                resources.add(new Iron(600,
                        Map1.getLevel() - ResLoader.getImage("Iron").getHeight()));
                resources.add(new Iron(sizeX / 2 + 600,
                        Map1.getLevel() - ResLoader.getImage("Iron").getHeight()));
                break;
            case 2:
                players.add(new Player(-1, this));
                players.add(new Player(-2, this));
                for (int i = 0; i < 4; i++) {
                    units.add(new Worker1(100 + i * 10, Map1.getLevel(), -1));
                    units.add(new Worker1(sizeX - 100 - i * 10, Map1.getLevel(), -2));
                }
                resources.add(new Stone(300,
                        Map1.getLevel() - ResLoader.getImage("Stone").getHeight()));
                resources.add(new Stone(sizeX / 2 - 300,
                        Map1.getLevel() - ResLoader.getImage("Stone").getHeight()));
                resources.add(new Iron(600,
                        Map1.getLevel() - ResLoader.getImage("Iron").getHeight()));
                resources.add(new Iron(sizeX / 2 + 600,
                        Map1.getLevel() - ResLoader.getImage("Iron").getHeight()));
                resources.add(new Stone(sizeX - 300,
                        Map1.getLevel() - ResLoader.getImage("Stone").getHeight()));
                resources.add(new Iron(sizeX - 600,
                        Map1.getLevel() - ResLoader.getImage("Iron").getHeight()));
                players.get(1).money = 1050;
                players.get(1).stone = 100;
                players.get(1).iron = 100;
                players.get(2).money = 1050;
                players.get(2).stone = 70;
                players.get(2).iron = 80;
                break;
        }
    }

    private void setRegime(int regime1) {
        switch (regime) {
            case "Waves":
                break;
            case "Survival":
                players.add(new Player(0, this));
                units.add(new Worker1(sizeX / 2, Map1.getLevel(), 0));
                units.add(new Worker1(sizeX / 2 + step, Map1.getLevel(), 0));
                units.add(new Worker1(sizeX / 2 - step, Map1.getLevel(), 0));
                units.add(new Worker1(sizeX / 2 - 2 * step, Map1.getLevel(), 0));
                units.add(new Worker1(sizeX / 2 + 2 * step, Map1.getLevel(), 0));
                thisFlag = 0;
                players.get(0).money = 10000;
                players.get(0).stone = 155;
                players.get(0).iron = 155;
                createPlayers(regime1);
                cameraX = -sizeX / 2 + width / 2;
                cameraY = 0;
                hero = new Hero(sizeX / 2, 200);
                break;
        }
    }

    public ArrayList<Unit> getUnits(int flag) {
        ArrayList<Unit> uns = new ArrayList<>();
        for (Unit unit : units) {
            if (unit.getFlag() == flag)
                uns.add(unit);
        }
        return uns;
    }

    public Base getBuilding() {
        return building;
    }

    public static ArrayList<Base> getBases(int flag) {
        ArrayList<Base> bs = new ArrayList<>();
        for (Base base : bases) {
            if (base.getFlag() == flag)
                bs.add(base);
        }
        return bs;
    }

    public static Player getPlayer(int flag) {
        for (Player player : players) {
            if (flag == player.flag)
                return player;
        }
        return null;
    }

    public Base pickNearestRes(String type, float xPos, int flag) {
        float dist = sizeX;
        Base base1 = null;
        for (Base base : bases) {
            if (Math.abs(xPos - base.getXPos()) < dist && base.getType().equals(type)
                    && base.getFlag() == flag) {
                dist = Math.abs(xPos - base.getXPos());
                base1 = base;
            }
        }
        return base1;
    }

    public float getNearestRes(Enum type, float xPos, int flag) {
        float dist = sizeX;
        Resource res1 = null;
        for (Resource resource : resources) {
            if (Math.abs(xPos - resource.getXPos()) < dist && resource.getType() == type
                    && resource.getFlag() == flag) {
                dist = Math.abs(xPos - resource.getXPos());
                res1 = resource;
            }
        }
        return res1.xPos;
    }

    public static Base getRes(float aimX, int flag) {
        for (Base base : bases) {
            if (base.getXPos() == aimX && base.getType().startsWith("Resource")
                    && base.getFlag() == flag)
                return base;
        }
        return null;
    }

    private void initParams(GameContainer gmc, int regime) {
        switch (regime) {
            case 1:
                sizeX = 4096;
                break;
            case 2:
                sizeX = 8192;
                break;

        }
        countButtons = 4;
        width = gmc.getWidth();
        height = gmc.getHeight();
        step = ResLoader.getScale() * 12;
        Map1.init(gmc);
        Map1.regime = regime;
        players = new ArrayList<>();
        bubbles = new ArrayList<>();
        units = new ArrayList<>();
        rockets = new ArrayList<>();
        buttons = new ArrayList<>();
        bases = new ArrayList<>();
        resources = new ArrayList<>();
        fish = new ArrayList<>();
        setRegime(regime);
        makeZero();
    }

    private void fillLists(GameContainer gmc) {
        for (int i = 0; i < 2; i++) {
            fish.add(new Fish((float) Math.random() * sizeX,
                    (float) Math.random() * gmc.getHeight(), "Fish1"));
        }
    }

    void init(GameContainer gmc, int regime) throws SlickException {
        ResLoader.setScale(2);
        ResLoader.load();
        initParams(gmc, regime);
        fillLists(gmc);
        inter = new Interface(gmc.getGraphics(), this);
        this.gmc = gmc;
    }

    private void makeZero() {
        chX = -1;
        chY = -1;
        chX1 = -1;
        chY1 = -1;
    }

    private void setChosen(float x, float y) {
        if (chX == -1 && chY == -1) {
            chX = x;
            chY = y;
        }
        chX1 = x;
        chY1 = y;
    }

    private void updateUnits(GameContainer gmc) {
        int count = 0;
        for (int i = 0; i < units.size(); i++) {
            units.get(i).behave(units);
            if (units.get(i).isChosen())
                count++;
            if (units.get(i).getHp() <= 0) {
                units.remove(i);
            }
        }
        if (gmc.getInput().isMousePressed(Input.MOUSE_RIGHT_BUTTON)) {
            for (Unit unit : units) {
                if (unit.chosen && !typeMen.equals("Placement")) {
                    unit.setAimX(gmc.getInput().getMouseX() - cameraX);
                    unit.setCondition("Moving");
                }
            }
        }
        if (count == 0 && typeMen.equals("Build"))
            typeMen = "";
    }

    private boolean checkFrame(float x, float y) {
        if (x > chX && x < chX1 && y > chY && y < chY1 && chX <= chX1 && chY <= chY1)
            return true;
        if (chX > chX1 && chY > chY1 && x > chX1 && x < chX && y > chY1 && y < chY)
            return true;
        else return false;
    }

    public void setUnitChosen(Unit unit) {
        unit.chosen = true;
        if (unit.getType().equals("Worker")) {
            countButtons = 4;
            typeMen = "Build";
            menLine = "Builder: " + Math.round(unit.getHp()) + " hp";
        }
        for (Base base : bases) {
            base.isCurrent = false;
        }
    }

    private void setPicked(Touch touch) {
        if (!inter.touchedInterface(xMouse, yMouse)) {
            if (!typeMen.equals("Placement"))
                typeMen = "";
            menLine = "";
        }
        boolean unitPicked = false;
        for (Unit unit : units) {
            if (!inter.touchedInterface(xMouse, yMouse))
                unit.chosen = false;
            if (checkFrame(unit.getxPos(), unit.getyPos()) && unit.getFlag() == thisFlag) {
                setUnitChosen(unit);
                unitPicked = true;
            }
        }
        for (Base base : bases) {
            if (!inter.touchedInterface(xMouse, yMouse))
                base.isCurrent = false;
            if (touch.equals(Touch.Choose)) {
                if (checkFrame(base.getXPos(), base.getYPos()) && !unitPicked && base.getFlag() == thisFlag) {
                    base.isCurrent = true;
                }
            } else if (base.isPressed(xMouse, yMouse)) {
                base.isCurrent = true;
            }
        }
    }

    private boolean checkAvailable() {
        boolean result = true;
        for (Base base : bases) {
            if (building.getXPos() + building.getSizeX() / 2 >
                    base.getXPos() - base.getSizeX() / 2
                    && building.getXPos() - building.getSizeX() / 2 <
                    base.getXPos() + base.getSizeX() / 2) {
                return false;
            } else if (building.getType().startsWith("Resource"))
                result = false;
        }
        for (Resource res : resources) {
            if (building.getXPos() + building.getSizeX() / 2 >
                    res.getXPos() - res.getSizeX() / 2
                    && building.getXPos() - building.getSizeX() / 2 <
                    res.getXPos() + res.getSizeX() / 2) {
                if (building.getType().startsWith("Resource")) {
                    result = true;
                    String line = "";
                    if (res.getType() == Resource.Type.Stone)
                        line = "ResourceS";
                    if (res.getType() == Resource.Type.Iron)
                        line = "ResourceI";
                    building = new Base(res.xPos, Map1.getLevel(), thisFlag, line);
                } else result = false;
            }
        }
        return result;
    }

    private void checkBuilding(GameContainer gmc) {
        if (building != null && typeMen.equals("Placement")) {
            building.setXPos(xMouse);
            if (gmc.getInput().isMousePressed(Input.MOUSE_LEFT_BUTTON)
                    && building.isAvailable(players.get(0).stone, players.get(0).iron, players.get(0).money)
                    && checkAvailable()
                    && !inter.touchedInterface(xMouse, yMouse)) {
                building.setHp(1);
                building.setFlagX(gmc.getInput().getMouseX() - cameraX);
                bases.add(building);
                players.get(0).money -= building.getThisPrice();
                players.get(0).stone -= building.getStone();
                players.get(0).iron -= building.getIron();
                building = null;
                typeMen = "";
            }
            if (gmc.getInput().isMouseButtonDown(Input.MOUSE_RIGHT_BUTTON)) {
                building = null;
                typeMen = "";
            }
        } else if (!typeMen.equals("Placement")) {
            building = null;
        }
    }

    private Touch classifyTouch() {
        if (Math.abs(chX - chX1) < 3 && Math.abs(chY - chY1) < 3)
            return Touch.Click;
        else return Touch.Choose;
    }

    void update(GameContainer gmc) {
        Input input = gmc.getInput();
        xMouse = input.getMouseX() - cameraX;
        yMouse = input.getMouseY();
        if (input.isMouseButtonDown(Input.MOUSE_LEFT_BUTTON)
                && !typeMen.equals("Placement"))
            setChosen(xMouse, yMouse);
        else {
            if (chX != -1)
                setPicked(classifyTouch());
            makeZero();
        }
        if (input.isKeyPressed(Input.KEY_ESCAPE)) {
            gmc.exit();
        }
        hero.behave(gmc);
        for (int i = 0; i < rockets.size(); i++) {
            Rocket rocket = rockets.get(i);
            rocket.behave(units);
            if (rocket.isShot() && rocket.isExp) {
                rockets.remove(i);
            }
        }
        for (Bubble bubble : bubbles) {
            bubble.behave();
        }
        for (Fish fish : fish) {
            fish.behave(gmc);
        }
        inter.setValues(cameraX, bases, typeMen, countButtons);
        updateBases(gmc);
        updateRes(gmc);
        updateUnits(gmc);
        for (Button button : buttons) {
            button.check(gmc);
        }
        checkBuilding(gmc);
        inter.updateMen(typeMen, input, thisFlag, xMouse, yMouse);
        updatePlayers();
    }

    private void updatePlayers() {
        for (Player player : players) {
            player.setLimUnits(bases);
            if (player.flag < 0)
                player.behave();
        }
    }

    public static void addStone(int stone1) {
        players.get(0).stone += stone1;
    }

    public static void addIron(int iron1) {
        players.get(0).iron += iron1;
    }

    private void drawAll() {
        for (Bubble bubble : bubbles) {
            bubble.draw();
        }
        for (Fish fish : fish) {
            fish.draw();
        }
        for (Resource resource : resources) {
            resource.draw();
        }
        for (Base base : bases) {
            base.draw(gmc);
        }
        for (Unit unit : units) {
            unit.draw(gmc);
        }
        for (Rocket rocket : rockets) {
            rocket.draw();
        }
        for (Button button : buttons) {
            button.draw();
        }
    }

    void render(GameContainer gmc) {
        Graphics graphics = gmc.getGraphics();
        graphics.translate(cameraX, cameraY);
        Map1.drawMap(gmc);
        drawAll();
        drawBuilds(gmc);
        Map1.drawBorder(gmc);
        hero.draw(gmc);
        Image img1 = ResLoader.getCoin();
        img1.draw(step - cameraX - img1.getWidth() / 2, step + cameraY);
        img1 = ResLoader.getImage("StoneIcon");
        img1.draw(step - cameraX - img1.getWidth() / 2, step * 2.05f + cameraY);
        img1 = ResLoader.getImage("IronIcon");
        img1.draw(step - cameraX - img1.getWidth() / 2, step * 3.1f + cameraY);
        graphics.drawRect(chX, chY, chX1 - chX, chY1 - chY);
        inter.drawMen(typeMen, menLine);
        drawPlayers(graphics);
    }

    private void drawPlayers(Graphics graphics) {
        /*for (int i = 0; i < players.size(); i++) {
            graphics.drawString("  " + players.get(i).money, step - cameraX, step * (i * 3 + 1) + cameraY);
            graphics.drawString("  " + players.get(i).stone, step - cameraX, step * (i * 3 + 2) + cameraY);
            graphics.drawString("  " + players.get(i).iron, step - cameraX, step * (i * 3 + 3) + cameraY);
        }*/
        graphics.drawString("  " + players.get(0).money, step - cameraX, step + cameraY);
        graphics.drawString("  " + players.get(0).stone, step - cameraX, step * 2 + cameraY);
        graphics.drawString("  " + players.get(0).iron, step - cameraX, step * 3 + cameraY);
    }

    private void updateBases(GameContainer gmc) {
        for (int i = 0; i < bases.size(); i++) {
            Base base = bases.get(i);
            if (base.isCurrent) {
                if (gmc.getInput().isKeyDown(Input.KEY_DELETE))
                    base.setHp(0);
                if (base.getHp() == base.getMaxHp()) {
                    typeMen = base.getType();
                    menLine = base.getType() + ": " + Math.round(base.getHp()) + " hp";
                }
            }
            if (base.getHp() == base.getMaxHp())
                base.behave(gmc, units);
            else if (base.getHp() <= -1)
                bases.remove(base);
            else if (base.isPressed(xMouse, yMouse) &&
                    gmc.getInput().isMousePressed(Input.MOUSE_RIGHT_BUTTON)
                    && !inter.touchedInterface(xMouse, yMouse)) {
                if (pickNearest(base.getXPos(), 0) != null) {
                    int index = units.indexOf(pickNearest(base.getXPos(), 0));
                    units.get(index).setAimX(base.getXPos());
                    units.get(index).setCondition("Working");
                    units.get(index).chosen = false;
                }
            }
        }
    }

    private void updateRes(GameContainer gmc) {
        for (Resource res : resources) {
            if (res.isPressed(xMouse, yMouse) &&
                    gmc.getInput().isMousePressed(Input.MOUSE_RIGHT_BUTTON)
                    && !inter.touchedInterface(xMouse, yMouse)
                    && !typeMen.equals("Placement")) {
                if (pickNearest(res.getXPos(), 0) != null) {
                    int index = units.indexOf(pickNearest(res.getXPos(), 0));
                    units.get(index).setAimX(res.getXPos());
                    units.get(index).setCondition("Extracting");
                    units.get(index).chosen = false;
                }
            }
        }
    }

    private void stopChosen() {
        for (Unit unit : units) {
            if (unit.isChosen()) {
                unit.setAimX(unit.getxPos());
            }
        }
    }

    private Unit pickNearest(float xPos, int flag) {
        Unit un1 = null;
        float distance = sizeX;
        for (Unit unit : units) {
            if (Math.abs(unit.getxPos() - xPos) < distance
                    && unit.getType().equals("Worker") && flag == unit.getFlag()
                    && unit.isChosen()) {
                distance = Math.abs(unit.getxPos() - xPos);
                un1 = unit;
            }
        }
        return un1;
    }

    public static Base pickNearestBase(float xPos, String type, int flag) {
        Base base = null;
        float distance = sizeX;
        String curType = "";
        for (Base bas : bases) {
            curType = bas.getType();
            if (bas.getFlag() == flag) {
                if (Math.abs(bas.getXPos() - xPos) < distance
                        && bas.getHp() == bas.getMaxHp()) {
                    if ((curType.equals("Storage") || curType.equals("Centre") && type.equals("Storage"))) {
                        distance = Math.abs(bas.getXPos() - xPos);
                        base = bas;
                    } else if (curType.equals(type)) {
                        distance = Math.abs(bas.getXPos() - xPos);
                        base = bas;
                    }
                }
            }
        }
        return base;
    }

    private void drawBuilds(GameContainer gmc) {
        if (building != null) {
            building.draw(gmc);
        }
    }

    public static int getSizeX() {
        return sizeX;
    }

    public static int getMoney() {
        return players.get(0).money;
    }

    public static void setMoney(int money) {
        players.get(0).money = money;
    }

    public static float getCameraX() {
        return cameraX;
    }

    public static float getCameraY() {
        return cameraY;
    }
}
