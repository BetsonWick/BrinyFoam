package Objects.Buildings;

import Fields.GameField;
import Landscape.Map1;
import Objects.Unit;
import Objects.Units.*;
import Resources.ResLoader;
import org.newdawn.slick.*;

import java.util.ArrayList;

public class Base {
    private float xPos, yPos, flagX;
    private int flag;
    private Image img1;
    public float timer = 0;
    private String type;
    private float hp, maxHp;
    public boolean isCurrent = false, destroy = false;
    private int await, thisPrice;
    private int stone, iron;
    private float[] chars1 = {1, 2000, 450};
    private float[] chars2 = {0.8f, 2000, 550};
    private float[] chars3 = {1.4f, 1000, 450};
    public int level = 1;
    public ArrayList<Unit> units;
    public float[] percentages;

    public static int getPrice(String type) {
        int price = 0;
        switch (type) {
            case "Tank1":
                price = 40;
                break;
            case "Tank2":
                price = 100;
                break;
            case "Tank3":
                price = 60;
                break;
            case "Worker":
                price = 20;
                break;
        }
        return price;
    }

    public void addToQueue(String type) {
        switch (type) {
            case "Worker":
                units.add(new Worker1(xPos, yPos, flag));
                break;
            case "Tank1":
                units.add(new Tank1(xPos, yPos, flag));
                break;
            case "Tank2":
                units.add(new Tank2(xPos, yPos, flag));
                break;
            case "Tank3":
                units.add(new Tank3(xPos, yPos, flag));
                break;
        }
    }

    public void setFlagX(float flagX) {
        this.flagX = flagX;
    }

    public float getFlagX() {
        return flagX;
    }

    public Base(float xPos, float yPos, int flag, String type) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.flag = flag;
        this.type = type;
        flagX = this.xPos;
        units = new ArrayList<>();
        int amount = 0;
        switch (type) {
            case "Centre":
                img1 = ResLoader.getBase1();
                maxHp = 25;
                await = 500;
                thisPrice = 60;
                amount = 1;
                stone = 30;
                iron = 30;
                break;
            case "Academy":
                img1 = ResLoader.getImage("Base7");
                maxHp = 30;
                thisPrice = 80;
                stone = 80;
                iron = 100;
                break;
            case "Battery":
                img1 = ResLoader.getImage("Base2");
                maxHp = 5;
                thisPrice = 30;
                stone = 10;
                iron = 10;
                break;
            case "Barracks":
                img1 = ResLoader.getBase4();
                maxHp = 15;
                await = 2000;
                thisPrice = 50;
                amount = 3;
                stone = 45;
                iron = 50;
                break;
            case "Energy":
                img1 = ResLoader.getBase3();
                maxHp = 10;
                await = 1000;
                thisPrice = 50;
                amount = 0;
                stone = 25;
                iron = 35;
                break;
            case "Storage":
                img1 = ResLoader.getBase5();
                maxHp = 5;
                thisPrice = 40;
                stone = 20;
                iron = 10;
                break;
            case "Turret":
                img1 = ResLoader.getImage("Base8");
                maxHp = 15;
                thisPrice = 100;
                stone = 30;
                iron = 40;
                break;
            case "ResourceS":
                img1 = ResLoader.getImage("Base9");
                maxHp = 5;
                thisPrice = 50;
                stone = 10;
                iron = 10;
                break;
            case "ResourceI":
                img1 = ResLoader.getImage("Base9");
                maxHp = 5;
                thisPrice = 50;
                stone = 10;
                iron = 10;
                break;
        }
        percentages = new float[amount];
        for (int i = 0; i < percentages.length; i++) {
            percentages[i] = 0;
        }
    }

    private int timer1 = 0;

    public int getQueue() {
        return units.size();
    }

    void drawFlag(Graphics graphics) {
        graphics.fillOval(flagX, Map1.getLevel(), 30, 30);
    }

    public void draw(GameContainer gmc) {
        Graphics graphics = gmc.getGraphics();
        if (hp < maxHp)
            img1.setAlpha(0.7f);
        else {
            img1.setAlpha(1);
            if (isCurrent)
                drawFlag(graphics);
        }
        if (isCurrent) {
            graphics.setColor(Color.red);
            graphics.drawOval(xPos - 5, yPos - img1.getHeight() * 1.5f, 10, 10);
            graphics.setColor(Color.white);
        }
        if (hp <= 0) {
            timer1++;
            int an = timer1 / 10;
            if (an >= 0 && an <= 9) {
                Rocket.drawAnim(an + 1, "Ex2", xPos, yPos - img1.getHeight() / 2);
            } else hp = -1;
        } else
            img1.draw(xPos - img1.getWidth() / 2, yPos - img1.getHeight());
    }

    public int countQueue(String type) {
        int count = 0;
        for (Unit unit : units) {
            if (unit.getType().equals(type))
                count++;
        }
        return count;
    }

    public boolean isPressedCircle(float x, float y) {
        boolean result = false;
        float distX, distY;
        distX = xPos - x;
        distY = yPos - y;
        float radius = (img1.getWidth() + img1.getHeight()) / 4;
        if (distY < Math.sqrt(radius * radius - distX * distX))
            result = true;
        return result;
    }

    public boolean isDestroy() {
        return destroy;
    }

    public boolean isPressed(float x, float y) {
        boolean result = false;
        float distX, distY;
        distX = xPos - x;
        distY = yPos - y;
        if (Math.abs(distX) < img1.getWidth() / 2 && Math.abs(distY) < img1.getHeight())
            result = true;
        return result;
    }

    public void addResource(int count, int flag) {
        if (type.equals("ResourceI"))
            GameField.getPlayer(flag).iron += count;
        if (type.equals("ResourceS"))
            GameField.getPlayer(flag).stone += count;
    }

    void createUnit() {

    }

    private void setPercentages() {
        switch (type) {
            case "Barracks":
                String[] els = units.get(0).getType().split("");
                int index = Integer.parseInt(els[els.length - 1]) - 1;
                percentages[index] = timer / units.get(0).spawnTime;
                break;
            case "Centre":
                percentages[0] = timer / units.get(0).spawnTime;
                break;
        }
    }

    void checkFlag(Input input) {
        if (input.isMousePressed(Input.MOUSE_RIGHT_BUTTON)) {
            flagX = input.getMouseX() - GameField.cameraX;
        }
    }

    public void behave(GameContainer gmc, ArrayList<Unit> units1) {
        if (isCurrent)
            checkFlag(gmc.getInput());
        switch (type) {
            case "Energy":
                timer += 10;
                if (timer > await) {
                    if (GameField.getPlayer(flag) != null)
                        GameField.getPlayer(flag).money += 1;
                    timer = 0;
                }
                break;
            default:
                if (units.size() > 0) {
                    if (timer < units.get(0).spawnTime)
                        timer += 10;
                    else timer = units.get(0).spawnTime;
                    for (int i = 0; i < percentages.length; i++) {
                        percentages[i] = 0;
                    }
                    setPercentages();
                    if (timer >= units.get(0).spawnTime && GameField.players.get(0).limUnits
                            > units.size()) {
                        Unit unit = units.get(0);
                        unit.setAimX(flagX);
                        units1.add(unit);
                        units.remove(unit);
                        timer = 0;
                    }
                }
                break;
        }
    }


    public void upgradeChars1() {

    }

    public void upgradeChars2() {

    }

    public void upgradeChars3() {
        chars3[0] *= 1.2f;
        chars3[1] /= 1.2f;
        chars3[2] *= 1.2f;
    }

    public float getHp() {
        return hp;
    }

    public float getMaxHp() {
        return maxHp;
    }

    public void setHp(float hp) {
        this.hp = hp;
    }

    public void setXPos(float xPos) {
        this.xPos = xPos;
    }

    public int getThisPrice() {
        return thisPrice;
    }

    public boolean isAvailable(int stone1, int iron1, int money1) {
        return stone1 >= stone && iron1 >= iron && money1 >= thisPrice;
    }

    public int getFlag() {
        return flag;
    }

    public float getSizeX() {
        return img1.getWidth();
    }

    public float getSizeY() {
        return img1.getHeight();
    }

    public float getXPos() {
        return xPos;
    }

    public float getYPos() {
        return yPos;
    }

    public void setCurrent(boolean current) {
        isCurrent = current;
    }

    public String getType() {
        return type;
    }

    public int getStone() {
        return stone;
    }

    public int getIron() {
        return iron;
    }

    public void setType(String type) {
        this.type = type;
    }
}
