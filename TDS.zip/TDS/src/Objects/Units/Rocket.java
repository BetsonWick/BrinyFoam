package Objects.Units;

import Landscape.Map1;
import Objects.Unit;
import Resources.ResLoader;
import org.newdawn.slick.Image;

import java.util.ArrayList;

public class Rocket {
    public String type;
    public float xPos, yPos, originX;
    float speed, distance = 0, maxDistance;
    float damage;
    Image img1;
    Image[] anim;
    public int flag;
    long timer = -1;
    int index = 0;
    public boolean shot = false, isExp = false;
    int flipped;

    public Rocket(String type, float xPos, float yPos, int flag, int flipped) {
        this.type = type;
        this.xPos = xPos;
        this.yPos = yPos;
        this.originX = xPos;
        this.flag = flag;
        this.flipped = flipped;
        switch (type) {
            case "Usual":
                speed = 3;
                damage = 1;
                maxDistance = 550;
                img1 = ResLoader.getbA1();
                anim = ResLoader.getAnim1();
                break;
            case "Armorer":
                speed = 4;
                damage = 1.5f;
                maxDistance = 700;
                img1 = ResLoader.getbB1();
                anim = ResLoader.getAnim1();
                break;
            case "Bomb":
                speed = 2;
                damage = 2;
                maxDistance = 400;
                img1 = ResLoader.getbC1();
                anim = ResLoader.getAnim1();
                break;
            default:
                speed = 0;
                damage = 0;
                img1 = ResLoader.getbA1();
        }
    }

    public static void drawAnim(int num, String type, float x, float y) {
        switch (type) {
            case "Ex1":
                if (num >= 0 && num <= 4) {
                    Image img1 = ResLoader.getImage("Ex1" + num);
                    img1.draw(x - img1.getWidth() / 2, y - img1.getHeight() / 2);
                }
                break;
            case "Ex2":
                if (num >= 0 && num <= 10) {
                    Image img1 = ResLoader.getImage("Ex2" + num);
                    img1.draw(x - img1.getWidth() / 2, y - img1.getHeight() / 2);
                }
                break;
        }
    }

    public void draw() {
        if (timer == -1)
            timer = System.currentTimeMillis();
        img1.draw(xPos - img1.getWidth() / 2, yPos - img1.getHeight() / 2);
    }

    private void checkCol(ArrayList<Unit> units) {
        for (Unit unit : units) {
            if (unit.getFlag() != flag) {
                if (Math.abs(unit.getxPos() - xPos) <= unit.getSize() / 4 && !type.equals("Explosion")) {
                    shot = true;
                    unit.setHp(unit.getHp() - damage);
                    break;
                }
            }
        }
    }

    int frame = 0;

    public void behave(ArrayList<Unit> units) {
        if (shot) {
            frame++;
            int an = frame / 10;
            if (an >= 0 && an <= 3) {
                img1 = ResLoader.getImage("Ex1" + (an + 1));
            } else isExp = true;
        } else {
            if (!type.equals("Bomb")) {
                xPos += speed * flipped;
                checkCol(units);
            } else yPos += speed;
            distance += speed;
            if (distance >= maxDistance)
                shot = true;
            if (type.equals("Bomb") && yPos >= Map1.getLevel()) {
                shot = true;
            }
        }
    }

    public boolean isShot() {
        return shot;
    }
}
