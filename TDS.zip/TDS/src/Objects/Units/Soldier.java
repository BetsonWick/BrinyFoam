package Objects.Units;

import Fields.GameField;
import Objects.Unit;

import java.util.ArrayList;

public class Soldier extends Unit {
    int timer = 0;

    public Soldier(float xPos, float yPos, int flag) {
        super(xPos, yPos, flag);
    }

    @Override
    public void behave(ArrayList<Unit> units) {
        super.behave(units);
        if (condition.equals("Shooting")) {
            if (target != null && Math.abs(aimX - xPos) <= img1.getWidth() / 4) {
                if (target.getxPos() > xPos)
                    flipped = 1;
                else flipped = -1;
                timer++;
                if (timer > loadSpeed) {
                    GameField.rockets.add(new Rocket("Armorer", xPos, yPos - 20, flag, flipped));
                    timer = 0;
                }
            } else timer = 0;
        } else target = null;
    }

}
